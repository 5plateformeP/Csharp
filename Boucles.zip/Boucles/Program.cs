﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Boucles
{
    class Program
    {
        private const string STOP = "STOP";
        // on pourra pas la modifier dans le programme apres 

        static void Main(string[] args)
        {
            // les listes = objets types 
            List<string> personnage = new List<string>();
            personnage.Add("Astérix");
            personnage.Add("Obelix");
            personnage.Add("Panoramix");
            personnage.Add("Falbala");
            personnage.Add("Idefix");
            personnage.Add("Astérix");

            Console.WriteLine(personnage[2]);
            personnage[2] = "AssuranceToutRisque";
            Console.WriteLine(personnage[2]);

            Console.WriteLine(Environment.NewLine);
            ParcourirLaListFor(personnage);

            personnage.Remove("Astérix");

            Console.WriteLine("\n avant tri");
            personnage.Sort();
            Console.WriteLine("\n apres tri");
            ParcourirLaListFor(personnage);

            Console.WriteLine("\n FOREACH");
            ParcourirForEach(personnage);


            // list
            // hashSet : Liste sans doublon : 
            //attention ont peut pas trier un hashSet
            // on maitrise pas l'ordre des éléments
            // sortedSet : HashSet trié automatiquement

            String saisie = null;
            // wile ( condition ) {}
            while (saisie?.ToUpper() != STOP)
            {
                Console.WriteLine("Saisie  quelques chose . STOP pour arrêter ");
                saisie = Console.ReadLine();
            }
            Console.WriteLine("premiere bouche passée ");

            while (saisie?.ToUpper() != STOP)
            {
                Console.WriteLine("Saisie  quelques chose . STOP pour arrêter ");
                saisie = Console.ReadLine();
            }
            Console.WriteLine(" 2eme bouche passée ");
            // Do wile permet d executer au moins 1 fois 
            do
            {
                Console.WriteLine("Saisie encore quelques chose . STOP pour arrêter ");
                saisie = Console.ReadLine();
            }
            while (saisie?.ToUpper() != STOP);

            // comment sortir d'une boucle 
            while (true)
            {
                Console.WriteLine("Saisie une derniere chose . STOP pour arrêter ");
                saisie = Console.ReadLine();

                // on sort de la boucle 
                if (saisie?.ToUpper() == STOP) break;

                // permet de passer a l'iteration suivants ( on repart sur le debut de la boucle sans faire la fin 
                // de ce qui est en dessous 
                if (saisie?.ToUpper() == "CONTINUER") continue;

                Console.WriteLine("vous avez saisi " + saisie);
            }
            foreach (string p in personnage)
            {
                Thread.Sleep(1000);
                Console.WriteLine(p);   
            }

            Parallel.ForEach(personnage, p =>
            {
                Console.WriteLine(p);
            });
            //
            HashSet<String> hasSet = new HashSet<string>(personnage);
            Console.WriteLine("\n Parcours du HaSHET ");

            //ParcourirForEach(hasSet.ToList()); premiere solution
            ParcourirForEach(hasSet);
        }
        // on met ienumerable car Foreach fonctionne sur un ienumerable et que les 2 HAshet et la list fonctionne avec
        // aller voir sur DSN des 3 sur internet pour le voir 
        private static void ParcourirForEach(IEnumerable<string> personnage)
        {
            foreach (string perso in personnage)
            {
                Console.WriteLine(perso);
            }
        }


        private static void ParcourirLaListFor(List<string> personnage)
        {
            for (int i = 0; i < personnage.Count; i++)
            { 
            Console.WriteLine(personnage[i]);
        }
        }
    }
}
