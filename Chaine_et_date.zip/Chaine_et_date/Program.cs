﻿using Chaine_et_date.Properties;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Chaine_et_date
{
    class Program
    {
        static void Main(string[] args)
        {
            // on est sur de l'objet plus de type primitif
           // Chaines();
           // Dates();
            UtilisationDesRessources();
        }

        private static void UtilisationDesRessources()
        {
            Console.WriteLine(Environment.NewLine + " Utilisation des Ressources ");
            // quand on tapes Resources CTRL ; on voit qu'il est dans date_et_date
            Console.WriteLine("Pattern : " + Resources.DATE_PATTERN);
            Console.WriteLine("Pattern : " + Resources.BONJOUR);
            // on affiche la date suivant la ressources qui ets le format de  la date qu'on a definie dans ressources
            Console.WriteLine(Environment.NewLine + " essai 1  ");


            Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-UK");
            Console.WriteLine(Resources.BONJOUR + " " + DateTime.Now.ToString(Resources.DATE_PATTERN));

            Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
            Console.WriteLine(Resources.BONJOUR + " " + DateTime.Now.ToString(Resources.DATE_PATTERN));

            Thread.CurrentThread.CurrentUICulture = new CultureInfo("en");
            Console.WriteLine(Resources.BONJOUR + " " + DateTime.Now.ToString(Resources.DATE_PATTERN));

            Console.WriteLine(Environment.NewLine + " essai 2  ");

            Console.WriteLine(" appel Fonction");
            Affichage("en-UK");
            Affichage("en-US");
            Affichage("en");

        }

        private static void Affichage(string langue)
        {
            Thread.CurrentThread.CurrentUICulture = new CultureInfo(langue);
            Console.WriteLine(Resources.BONJOUR + " " + DateTime.Now.ToString(Resources.DATE_PATTERN));
        }

        private static void Dates()
        {
            DateTime maintenant = DateTime.Now;
            Console.WriteLine(maintenant) ;
            Console.WriteLine(maintenant.ToString("yyy-MM-dd HH:mm:ss")) ;

            CultureInfo Culture = new CultureInfo("en-US");
            Console.WriteLine(maintenant.ToString(Culture));

            CultureInfo Culture1 = new CultureInfo("fr-FR");
            Console.WriteLine(maintenant.ToString(Culture1));

            // changer la culture de toute l'application ici ESPAGNOL 
            Thread.CurrentThread.CurrentCulture = new CultureInfo("ES");
            Console.WriteLine(maintenant.ToString("dddd dd MMMM yy"));
            Console.WriteLine(maintenant.ToShortDateString());
            // linverse passer un string en chaine 
            DateTime  dateFromString = DateTime.Parse("03/01/2020");
            Console.WriteLine(dateFromString.ToString("yyy-MM-dd HH:mm:ss"));

            // manipulation de date
            // ajoute des jous mois année
            DateTime demain = maintenant.AddDays(1);
            Console.WriteLine("Aujourd hui : " + maintenant);
            Console.WriteLine("Demain : " + demain );
            DateTime hier = maintenant.AddDays(-1);
            Console.WriteLine("Aujourd hui : " + hier);
            // si on prend la culture arabe ou hebreux , on sera sur le calendrier arabe ou hebreux
            Console.WriteLine(maintenant.ToString(new CultureInfo("fa")));


        }

        private static void Chaines()
        {
            string maChaine = null;
            // True et du coup plante pas car il fait la fonction Isnull0Emplty et fait pas le trim qui lui aurai planté
            Console.WriteLine(string.IsNullOrEmpty(maChaine?.Trim())); 
            Console.WriteLine(maChaine);
            maChaine = "Hello Word";
            Console.WriteLine("MAJUSCULE : "+maChaine.ToUpper()); // affiche en majuscule
            Console.WriteLine("MINISCULE : "+maChaine.ToLower()); //affiche en minuscule
            Console.WriteLine("A partir du 7eme caractères : " + maChaine.Substring(6)); //affiche à partir de la position donnée
            Console.WriteLine("Affiche 7 et 8eme caractères : " + maChaine.Substring(6,2)); //affiche à partir de la position donnée
            Console.WriteLine("MINISCULE : ".ToLower()); //affiche en minuscule en minuscule
            Console.WriteLine("Sup des espaces  : " + maChaine.Substring(6,2)); //affiche à partir de la position donnée
            Console.WriteLine("         MINISCULE :  ".ToLower().Trim()); //affiche en minuscule en minuscule
            maChaine = maChaine.Replace(" ", ""); // remplace le space par rien 
            Console.WriteLine("Sans espace " + maChaine);
            Console.WriteLine(maChaine.Replace("Word", " La Terre")); // remplace le space par rien 

            // padLegft padRight ajout de caractère a doite ou gauche 
            Console.WriteLine("7".PadLeft(3, '0'));  // 007
            Console.WriteLine("712".PadLeft(3, '0')); //712
            Console.WriteLine("71142".PadLeft(3, '0'));//71142

            Console.WriteLine("taille chaine "+ maChaine.Length); //9

            Console.WriteLine(string.IsNullOrEmpty(maChaine.Trim()));  // est ce que la chaine est null ou vide // false
            Console.WriteLine(string.IsNullOrWhiteSpace("    " ));

            // stringformat
            Console.WriteLine(String.Format("{1} : Ma Chaine avec param {0} et  {1} ",333,"TOTO"));
            string toto = "TOTO";
            Console.WriteLine($"{toto} : Ma Chaine avec param {333} et  {toto} ");

            string [] colonnes = {"nom","prenom","age"};
            Console.WriteLine($"SELECT {string.Join(", ",colonnes )} FROM maTable") ;

            // traiter du csv
            string csv = "gérard;René;43;Comptable";
            String[] TableauCsv = csv.Split(';');  // il decoupe sur le ; 
            Console.WriteLine("Son age est de " + TableauCsv[2]);

            string csv2 = "gérard;René;43;Comptable \n Roselyne ;Arthur;43;Comptable";
            String[] ligne = TableauCsv = csv2.Split('\n');
            Console.WriteLine("Nombre de ligne " + ligne.Length );
            Console.WriteLine(ligne[ligne.Length - 1].Split(';') [2]);

            // pour definit une constnte qui sera re-utilisé
            string vide = string.Empty; // ""

            // string Bulder , si on a beaucoup de concatenation
            // init l'objet stringBuilder
            StringBuilder sb = new StringBuilder();
            sb.Append("select ");
                sb.Append(" a ");
                sb.Append("FROM ");
                sb.Append("  ma table ");

            Console.WriteLine(sb.ToString());

            string maChaine2 = "Coucou ";
            maChaine2 += "Jean-Michel ";
            Console.WriteLine(maChaine2);

            int a = 2;
            int b = 7;
            Console.WriteLine("resulat : " + a + b); // 27
            Console.WriteLine("resulat : " + (a + b)); // 9

            Console.WriteLine(a + b++ + "3" + 5); // 2 +7 ( car avant le b++) puis chaine 3 puis 5 => 935
         

        }
    }
}
