﻿namespace FormationApprofoncdissement
{
    partial class FormPro
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnAfficherFichier = new System.Windows.Forms.Button();
            this.LvLogs = new System.Windows.Forms.ListView();
            this.Liste = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.GbLog = new System.Windows.Forms.GroupBox();
            this.ChkFiltrer = new System.Windows.Forms.CheckBox();
            this.BtnSauvegarde = new System.Windows.Forms.Button();
            this.dgvMonuments = new System.Windows.Forms.DataGridView();
            this.LblNom = new System.Windows.Forms.Label();
            this.LblDescription = new System.Windows.Forms.Label();
            this.TbNom = new System.Windows.Forms.TextBox();
            this.TbDescription = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtSave = new System.Windows.Forms.Button();
            this.BtSupression = new System.Windows.Forms.Button();
            this.BtNouveau = new System.Windows.Forms.Button();
            this.BtDialogue = new System.Windows.Forms.Button();
            this.GbLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMonuments)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnAfficherFichier
            // 
            this.BtnAfficherFichier.Location = new System.Drawing.Point(65, 105);
            this.BtnAfficherFichier.Name = "BtnAfficherFichier";
            this.BtnAfficherFichier.Size = new System.Drawing.Size(94, 41);
            this.BtnAfficherFichier.TabIndex = 0;
            this.BtnAfficherFichier.Text = "Affichier Fichier";
            this.BtnAfficherFichier.UseVisualStyleBackColor = true;
            this.BtnAfficherFichier.Click += new System.EventHandler(this.BtnAfficherFichier_Click);
            // 
            // LvLogs
            // 
            this.LvLogs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Liste});
            this.LvLogs.HideSelection = false;
            this.LvLogs.Location = new System.Drawing.Point(33, 32);
            this.LvLogs.Name = "LvLogs";
            this.LvLogs.Size = new System.Drawing.Size(311, 428);
            this.LvLogs.TabIndex = 1;
            this.LvLogs.UseCompatibleStateImageBehavior = false;
            this.LvLogs.View = System.Windows.Forms.View.Details;
            this.LvLogs.SelectedIndexChanged += new System.EventHandler(this.LvLogs_SelectedIndexChanged);
            // 
            // Liste
            // 
            this.Liste.Text = "Liste colonne et fichier";
            this.Liste.Width = 300;
            // 
            // GbLog
            // 
            this.GbLog.Controls.Add(this.LvLogs);
            this.GbLog.Location = new System.Drawing.Point(536, 163);
            this.GbLog.Name = "GbLog";
            this.GbLog.Size = new System.Drawing.Size(374, 489);
            this.GbLog.TabIndex = 2;
            this.GbLog.TabStop = false;
            this.GbLog.Text = "Logs";
            // 
            // ChkFiltrer
            // 
            this.ChkFiltrer.AutoSize = true;
            this.ChkFiltrer.Location = new System.Drawing.Point(166, 105);
            this.ChkFiltrer.Name = "ChkFiltrer";
            this.ChkFiltrer.Size = new System.Drawing.Size(75, 17);
            this.ChkFiltrer.TabIndex = 3;
            this.ChkFiltrer.Text = "Filtrer\".txt\"";
            this.ChkFiltrer.UseVisualStyleBackColor = true;
            // 
            // BtnSauvegarde
            // 
            this.BtnSauvegarde.Location = new System.Drawing.Point(65, 152);
            this.BtnSauvegarde.Name = "BtnSauvegarde";
            this.BtnSauvegarde.Size = new System.Drawing.Size(94, 43);
            this.BtnSauvegarde.TabIndex = 4;
            this.BtnSauvegarde.Text = "Sauvegarde";
            this.BtnSauvegarde.UseVisualStyleBackColor = true;
            this.BtnSauvegarde.Click += new System.EventHandler(this.BtnSauvegarde_Click);
            // 
            // dgvMonuments
            // 
            this.dgvMonuments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMonuments.Location = new System.Drawing.Point(12, 192);
            this.dgvMonuments.MultiSelect = false;
            this.dgvMonuments.Name = "dgvMonuments";
            this.dgvMonuments.ReadOnly = true;
            this.dgvMonuments.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMonuments.Size = new System.Drawing.Size(486, 228);
            this.dgvMonuments.TabIndex = 5;
            this.dgvMonuments.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMonuments_RowEnter);
            this.dgvMonuments.SelectionChanged += new System.EventHandler(this.dgvMonuments_SelectionChanged);
            // 
            // LblNom
            // 
            this.LblNom.AutoSize = true;
            this.LblNom.Location = new System.Drawing.Point(9, 29);
            this.LblNom.Name = "LblNom";
            this.LblNom.Size = new System.Drawing.Size(29, 13);
            this.LblNom.TabIndex = 6;
            this.LblNom.Text = "Nom";
            // 
            // LblDescription
            // 
            this.LblDescription.AutoSize = true;
            this.LblDescription.Location = new System.Drawing.Point(12, 76);
            this.LblDescription.Name = "LblDescription";
            this.LblDescription.Size = new System.Drawing.Size(60, 13);
            this.LblDescription.TabIndex = 7;
            this.LblDescription.Text = "Description";
            // 
            // TbNom
            // 
            this.TbNom.Location = new System.Drawing.Point(100, 19);
            this.TbNom.Name = "TbNom";
            this.TbNom.Size = new System.Drawing.Size(295, 20);
            this.TbNom.TabIndex = 8;
            // 
            // TbDescription
            // 
            this.TbDescription.Location = new System.Drawing.Point(100, 58);
            this.TbDescription.Multiline = true;
            this.TbDescription.Name = "TbDescription";
            this.TbDescription.Size = new System.Drawing.Size(295, 45);
            this.TbDescription.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtNouveau);
            this.groupBox1.Controls.Add(this.BtSupression);
            this.groupBox1.Controls.Add(this.BtSave);
            this.groupBox1.Controls.Add(this.LblNom);
            this.groupBox1.Controls.Add(this.TbDescription);
            this.groupBox1.Controls.Add(this.LblDescription);
            this.groupBox1.Controls.Add(this.TbNom);
            this.groupBox1.Controls.Add(this.dgvMonuments);
            this.groupBox1.Location = new System.Drawing.Point(26, 201);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(504, 426);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Zone de Base de Donnée";
            // 
            // BtSave
            // 
            this.BtSave.Location = new System.Drawing.Point(414, 151);
            this.BtSave.Name = "BtSave";
            this.BtSave.Size = new System.Drawing.Size(75, 23);
            this.BtSave.TabIndex = 10;
            this.BtSave.Text = "&Sauvegarder";
            this.BtSave.UseVisualStyleBackColor = true;
            this.BtSave.Click += new System.EventHandler(this.BtSave_Click);
            // 
            // BtSupression
            // 
            this.BtSupression.Location = new System.Drawing.Point(279, 150);
            this.BtSupression.Name = "BtSupression";
            this.BtSupression.Size = new System.Drawing.Size(75, 23);
            this.BtSupression.TabIndex = 11;
            this.BtSupression.Text = "S&upression";
            this.BtSupression.UseVisualStyleBackColor = true;
            this.BtSupression.Click += new System.EventHandler(this.BtSupression_Click);
            // 
            // BtNouveau
            // 
            this.BtNouveau.Location = new System.Drawing.Point(158, 150);
            this.BtNouveau.Name = "BtNouveau";
            this.BtNouveau.Size = new System.Drawing.Size(75, 23);
            this.BtNouveau.TabIndex = 12;
            this.BtNouveau.Text = "Nouveau";
            this.BtNouveau.UseVisualStyleBackColor = true;
            this.BtNouveau.Click += new System.EventHandler(this.BtNouveau_Click);
            // 
            // BtDialogue
            // 
            this.BtDialogue.Location = new System.Drawing.Point(687, 40);
            this.BtDialogue.Name = "BtDialogue";
            this.BtDialogue.Size = new System.Drawing.Size(173, 23);
            this.BtDialogue.TabIndex = 11;
            this.BtDialogue.Text = "Afficher Form";
            this.BtDialogue.UseVisualStyleBackColor = true;
            this.BtDialogue.Click += new System.EventHandler(this.BtDialogue_Click);
            // 
            // FormPro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(931, 664);
            this.Controls.Add(this.BtDialogue);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BtnSauvegarde);
            this.Controls.Add(this.ChkFiltrer);
            this.Controls.Add(this.GbLog);
            this.Controls.Add(this.BtnAfficherFichier);
            this.Name = "FormPro";
            this.Text = "Approfondissement";
            this.Load += new System.EventHandler(this.FormPro_Load);
            this.GbLog.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMonuments)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnAfficherFichier;
        private System.Windows.Forms.ListView LvLogs;
        private System.Windows.Forms.GroupBox GbLog;
        private System.Windows.Forms.CheckBox ChkFiltrer;
        private System.Windows.Forms.Button BtnSauvegarde;
        private System.Windows.Forms.ColumnHeader Liste;
        private System.Windows.Forms.DataGridView dgvMonuments;
        private System.Windows.Forms.Label LblNom;
        private System.Windows.Forms.Label LblDescription;
        private System.Windows.Forms.TextBox TbNom;
        private System.Windows.Forms.TextBox TbDescription;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtSave;
        private System.Windows.Forms.Button BtNouveau;
        private System.Windows.Forms.Button BtSupression;
        private System.Windows.Forms.Button BtDialogue;
    }
}

