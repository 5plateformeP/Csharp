﻿using FormationApprofondissementBL;
using FormationApprofondissementBL.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormationApprofoncdissement
{
    public partial class FormPro : Form
    {
        private List<string> logs;
        private monument SelectedMonument;
        private bool isLoaded; 
        public FormPro()
        {
            InitializeComponent();
            //logs = new List<string>();
            Init();
        }

        private void Init()
        {
            logs = ManipulationFichiers.ReadFile();
            AfficherLogs();
            // init de la zone de restitution des la bd 
            dgvMonuments.DataSource = MonumentDAO.FindAll();
        }

        private void BtnAfficherFichier_Click(object sender, EventArgs e)
        {
           List<string> fichiers = ManipulationFichiers.AfficherFichiers(logs, ChkFiltrer.Checked);
            
            AfficherLogs();
            foreach (string fichier in fichiers)
            {
                LvLogs.Items.Add(fichier);
            }
        }

        private void AfficherLogs()
        {
            // ( OnActivated fait un clear du composant box pas de la log )
            LvLogs.Items.Clear();
            foreach (string log in logs)
            {
                LvLogs.Items.Add(log);
            }
        }

        private void LvLogs_SelectedIndexChanged(object sender, EventArgs e)
        {    }

        private void BtnSauvegarde_Click(object sender, EventArgs e)
        {
            ManipulationFichiers.Sauvegarde(logs);
            AfficherLogs();
        }

        private void BtSave_Click(object sender, EventArgs e)
        {
            int selectedId = SelectedMonument != null ?
             ((monument)dgvMonuments
                 .SelectedRows[0]
                 .DataBoundItem).id 
                 :0
                 ;


            if (SelectedMonument != null)
            {
                SelectedMonument.nom = TbNom.Text;
                SelectedMonument.description = TbDescription.Text;
                MonumentDAO.Update(SelectedMonument);
            }
            else
            {
                monument nouveauMonument = new monument();
                nouveauMonument.nom = TbNom.Text;
                nouveauMonument.description = TbDescription.Text;
                MonumentDAO.Create(nouveauMonument);
            }
           

            //on force le rafraichissement 
            // sur certains controle , on doit d'abord re-init la datasourceà null
            // avant de lui re-affecter une collection, sinon l'affichage ne se fait pas 
            dgvMonuments.DataSource = null;
            dgvMonuments.DataSource = MonumentDAO.FindAll();
            TbDescription.Text = String.Empty;
            TbNom.Text = String.Empty;

            for (int i = 0; i < dgvMonuments.Rows.Count; i++)
            {
                monument item = (monument)dgvMonuments
                    .Rows[i]
                    .DataBoundItem;

                if (i == selectedId)
                {
                    dgvMonuments.Rows[i].Selected = true;
                }
            }
            
        }

        private void dgvMonuments_SelectionChanged(object sender, EventArgs e)
        {
            // on est loadé et plus d'une ligne dans la restitution
            if (isLoaded && dgvMonuments.SelectedRows.Count > 0)
            {
                 SelectedMonument = (monument)dgvMonuments
                    .SelectedRows[0]
                    .DataBoundItem;

                TbNom.Text = SelectedMonument.nom;
                TbDescription.Text = SelectedMonument.description;

            }
        }

        private void dgvMonuments_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
           
        }
        /// <summary>
        ///  chargement de l'ecran , on y arrive par double clique quel 'ecran Design
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormPro_Load(object sender, EventArgs e)
        {
            isLoaded = true;
            dgvMonuments.ClearSelection();
        }

        private void BtSupression_Click(object sender, EventArgs e)
        {

            if (SelectedMonument != null)
            {
                MonumentDAO.Delete(SelectedMonument.id);
                dgvMonuments.DataSource = null;
                dgvMonuments.DataSource = MonumentDAO.FindAll();
                TbDescription.Text = String.Empty;
                TbNom.Text = String.Empty;
                AfficherLogs();
            }
        }

        private void BtNouveau_Click(object sender, EventArgs e)
        {
            SelectedMonument = null;
            TbDescription.Text = String.Empty;
            TbNom.Text = String.Empty;
            dgvMonuments.ClearSelection();
            BtSupression.Enabled = false;
            TbNom.Focus();

           
        }

        private void BtDialogue_Click(object sender, EventArgs e)
        {
            FormProcess form = new FormProcess();
            //Form.Show();
            DialogResult result = form.ShowDialog();
            // TODO recupération de proprite de la form plus traitement
            if (result == DialogResult.Cancel)
            {
                MessageBox.Show("On a fermé la dial");
            }

            //Ferme la fenetre en cours ici la fenetre principe 
            // this.Close();

        }
    }
}
