﻿namespace FormationApprofoncdissement
{
    partial class FormProcess
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtNotePad = new System.Windows.Forms.Button();
            this.BtBoucle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtNotePad
            // 
            this.BtNotePad.Location = new System.Drawing.Point(167, 90);
            this.BtNotePad.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtNotePad.Name = "BtNotePad";
            this.BtNotePad.Size = new System.Drawing.Size(203, 62);
            this.BtNotePad.TabIndex = 0;
            this.BtNotePad.Text = "NotePad";
            this.BtNotePad.UseVisualStyleBackColor = true;
            this.BtNotePad.Click += new System.EventHandler(this.BtNotepad_Click);
            // 
            // BtBoucle
            // 
            this.BtBoucle.Location = new System.Drawing.Point(167, 159);
            this.BtBoucle.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtBoucle.Name = "BtBoucle";
            this.BtBoucle.Size = new System.Drawing.Size(203, 95);
            this.BtBoucle.TabIndex = 1;
            this.BtBoucle.Text = "Les boucles";
            this.BtBoucle.UseVisualStyleBackColor = true;
            this.BtBoucle.Click += new System.EventHandler(this.BtBoucle_Click);
            // 
            // FormProcess
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1149, 684);
            this.Controls.Add(this.BtBoucle);
            this.Controls.Add(this.BtNotePad);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FormProcess";
            this.Text = "FormProcess";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtNotePad;
        private System.Windows.Forms.Button BtBoucle;
    }
}