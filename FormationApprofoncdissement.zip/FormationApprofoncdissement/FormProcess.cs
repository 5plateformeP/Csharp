﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormationApprofoncdissement
{
    public partial class FormProcess : Form
    {
        public FormProcess()
        {
            InitializeComponent();
        }

        private void BtNotepad_Click(object sender, EventArgs e)
        {
            // utilisation de process
            using ( Process process = new Process() )
            {
                // on indique le nom du process
                // s il est connu dans les varaibles d'envi ou son chemin 
                process.StartInfo.FileName = "notepad";
                process.Start();

                // on dort 3 secondes
                Thread.Sleep(3000);
                // est ce qu'il existe toujours 
                if (!process.HasExited)
                    {
                    process.Kill();
                }
            }
        }

        private void BtBoucle_Click(object sender, EventArgs e)
        {
            using (Process process = new Process())
            {
                process.StartInfo.FileName = @"‪‪C:\tmp2020s_11\Boucles.exe";
                process.Start();
            }
        }
    }
}

/*
 * F5 : lancer l'application en mode debug
CTRL+F5 : lancer l'application sans le mode debug
(ajoute dans une application console une ligne de pause à la fin du programme)

F12 (ou CTRL+CLIC) : aller à la définition
Shift+F12 : voir toutes les références (d'une variable, d'une méthode) 

CTRL+ESPACE : autocomplétion (entrée pour valider)

CTRL+; Vous propose une ou des solutions à un problème (convention de nommage, simplification, etc...)

CTRL+: mettre ou retirer les commentaires
CTRL+K+C : mettre en commentaire
CTRL+K+U : retirer en commentaire

CTRL+SHIFT+B : Compiler

Debug (F5):
    F5 : pour aller au prochain point d'arrêt (ou jusqu'à la fin du programme)
    F10 : instruction suivante
    F11 : entrer dans la méthode ou, si ce n'est pas possible, instruction suivante
    
CTRL+SHIFT+U : passer majuscules
CTRL+U : passer minuscules

ALT+glisser souris : sélection multigne


WINFORM :
F7 / SHIFT+F7 sur une winform pour basculer en code / mode design

CTRL+SHIFT+S : sauvegarder tous les fichiers

*/
