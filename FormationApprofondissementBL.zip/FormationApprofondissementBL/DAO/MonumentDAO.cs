﻿using FormationApprofondissementBL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FormationApprofondissementBL.DAO
{
    public class MonumentDAO
    {
        // toute les methodes d'acce a la base de donnée
        /// <summary>
        /// monumment est sans s donc vient du modele 
        /// </summary>
        /// <param name="m"></param>
        public static void Create(monument m)
        {
            using (MonumentEntities context = new MonumentEntities())
            {
                // eventuellement mettre un verrou pour empecher les acces concurents
                lock (context.monuments)
                {
                    //an ajoute un monument dans la base de données
                    context.monuments.Add(m);
                    // commit
                    context.SaveChanges();
                }
            }
        }
        public static monument FindById(int id)
        {
            using (MonumentEntities context = new MonumentEntities())
            {
                context.monuments.SqlQuery("Select + from monument where id =" + id);
                // renvoie le premier meme si rien n'existe 
                //return context.monuments.Where(m => m.id == id).FirstOrDefault ;
                // idem que au dessus 
                return context.monuments.FirstOrDefault(m => m.id == id);
                // ça fait la jointure entre point et monument via position ( ne fonctionne pas sur la versio nqu'on a )
                //return context.monuments.Include("position").FirstOrDefault(m => m.id == id);  
            }
        }
        public static List<monument> FindAll()
        {
            using (MonumentEntities context = new MonumentEntities())
            {
                return context.monuments.OrderBy(m => m.nom).ToList();
            }
        }
        public static List<string> FindAllNoms()
        {
            using (MonumentEntities context = new MonumentEntities())
            {
                return context.monuments.OrderBy(m => m.nom)
                    .Select(m => m.nom)
                    .ToList();
            }

        }
        public static List<MonumentDTO> FinfAllMonumentDTO()
        {
            using (MonumentEntities context = new MonumentEntities())
            {
                return context.monuments
                  .OrderBy(m => m.nom)
                  .Select(m => new MonumentDTO(m.nom, m.description))
                  .ToList();
            }
        }
        public static void Update(monument m)
        {
            using (MonumentEntities context = new MonumentEntities())
            {
                monument monumentDB = context.monuments
                    .FirstOrDefault(mdb => mdb.id == m.id);
                if (monumentDB != null)
                {
                    monumentDB.nom = m.nom;
                    monumentDB.description = m.description;
                }
                context.SaveChanges();
            }
        }
        public static void Delete(int id)
        {
            using (MonumentEntities context = new MonumentEntities())
            {
                monument monumentDB = context.monuments
                    .FirstOrDefault(mdb => mdb.id == id);
                context.monuments.Remove(monumentDB);
                context.SaveChanges();
            }
        }
    }
}
