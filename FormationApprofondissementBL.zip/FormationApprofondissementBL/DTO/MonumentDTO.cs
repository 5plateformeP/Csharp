﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormationApprofondissementBL.DTO
{
    public class MonumentDTO
    {
        public string Nom { get; set; }
        public string Description { get; set; }
        public MonumentDTO(string nom, string description)
        {
            Nom = nom;
            Description = description;
        }
    }
}
