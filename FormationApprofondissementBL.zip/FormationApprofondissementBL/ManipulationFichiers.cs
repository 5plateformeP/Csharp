﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormationApprofondissementBL
{

    public class ManipulationFichiers
    {
        // creation d'une conctante pour le repertoire ds fichiers
        private const string PATH = @"c:\tmp2020s_11";
        private const string LOGS = "logs.txt";

        // Affichier tous les fichiers d'un repertoire
        public static List<string> AfficherFichiers(List<string> logs, bool filtrer)
        {
            List<string> ListeFichier = new List<string>();
            DirectoryInfo repertoire = VerifierRepertoire(logs);
            // en terner
            FileInfo[] fichiers = filtrer ? repertoire.GetFiles("*.txt") : repertoire.GetFiles();
            logs.Add($"Filtre *.txt dans {PATH} : {filtrer} ");
            foreach (FileInfo file in fichiers)
            {
                ListeFichier.Add($" {file.Name } -  {file.Length} o ");
            }

            return ListeFichier;
        }

        private static DirectoryInfo VerifierRepertoire(List<string> logs)
        {
            // objet qui manipul le repertoire 
            DirectoryInfo repertoire = new DirectoryInfo(PATH);
            // le repertoire existe ? 
            if (!repertoire.Exists)
            {
                repertoire.Create();
                logs.Add($"reperoire {PATH} créé :.");
            }
            else
            {
                logs.Add($"Le répertoire {PATH} existe déjà. ");
            }

            return repertoire;
        }

        public static void Sauvegarde(List<string> logs)
        {
            string cheminLogs = Path.Combine(PATH,LOGS);
            VerifierRepertoire(logs);
            // ecrire dans un fichier: on doit utiliser un flux
            using (StreamWriter fluxEnEcriture = new StreamWriter(cheminLogs,true,Encoding.UTF8))
            {
                foreach(string log in logs)
                {
                    fluxEnEcriture.WriteLine(log);
                }
            }
            logs.Add($"Fichier sauvé  {cheminLogs} . ");

        }
        public static List<string> ReadFile()
        {
            List<string> resultats = new List<string>();
            string fichierLog = Path.Combine(PATH, LOGS);

            FileInfo fichier = new FileInfo(fichierLog);
            if (fichier.Exists)
            {
                using(StreamReader reader = new StreamReader(fichierLog, Encoding.UTF8))
                {
                    while (reader.Peek()>= 0)
                    {
                        resultats.Add(reader.ReadLine());
                    }
                }
            }
            else
            {
                resultats.Add($"Fichier {fichierLog} non trouvé "); 
            }
            return resultats; 
        }
    }
   
}
