﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Genericite
{
    public class Permuteur<T>
    {
        public T A { get; set; }
        public T B { get; set; }

        public Permuteur(T a, T b)
        { A = a;
            B = b; 
        }
        public void Permuter()
        {
            T c = A;
            A = B;
            B = c;
        }
    }
}
