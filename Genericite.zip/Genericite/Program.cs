﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Genericite
{
    class Program
    {
        static void Main(string[] args)
        {
            Permuteur<T> permuteur = new Permuteur<T>(7,42);
            T a = permuteur.A;
            Console.WriteLine(a);
            Console.WriteLine(permuteur.B);
            permuteur.Permuter();

            a = permuteur.A;
            Console.WriteLine(a);
            Console.WriteLine(permuteur.B);

            Permuteur<int> permuteur2 = new Permuteur<T>("TOTO", "TITI");

        }
    }
}
