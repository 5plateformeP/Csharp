﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionDesSalariesInterface
{
    public interface IPayables
    {
        // on a que des methodes abtrait et public 
        void Payer();
        bool IsJourDeLaPaye(DateTime date);
    }
}
