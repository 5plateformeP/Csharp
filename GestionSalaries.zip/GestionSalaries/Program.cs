﻿using GestionDesSalariesInterface;
using GestionSalariesBL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace GestionSalaries
{
    class Program
    {
        public static object XmlSerilizer { get; private set; }

        static void Main(string[] args)
        {
            List<Personne> MembreDeLaReunion = new List<Personne>();
            List<Salarie> TousLesSalaries = new List<Salarie>();


            Salarie leSalarie = new Salarie();
            leSalarie.Nom = "Bernard";
            Console.WriteLine(leSalarie.Nom);
            leSalarie.Nom = "A";
            Console.WriteLine(leSalarie.Nom);
            leSalarie.Nom = null;
            Console.WriteLine(leSalarie.Nom);
            leSalarie.Nom = "Pierre";
            Console.WriteLine(leSalarie.Nom);

            Console.WriteLine("\n ");

            // on cree d'abord le salier et apres on l'affecte en tent que responsable 
            //Salarie superieur = new Salarie("PICHOT","RENE") ;
            //leSalarie.SuperieurHierarchique = superieur;

            leSalarie.SuperieurHierarchique = new Salarie("PICHOT", "RENE");
            Console.WriteLine("superieur : " + leSalarie.SuperieurHierarchique.Nom
                + ' ' + leSalarie.SuperieurHierarchique.Prenom);

            Console.WriteLine("\n ");
            //on fait une copie de referente pas d'objet   
            Salarie salarie2 = new Salarie();
            salarie2 = leSalarie;
            Console.WriteLine(salarie2.Nom);
            // pour recopie un salarie dans un autre il faudra recopie d'abord nom puis le prenom pas sur la class

            leSalarie.Nom = "Bidet";
            leSalarie.Prenom = "Anne-Marie";
            Console.WriteLine(leSalarie.Nom); // bidet
            Console.WriteLine(salarie2.Nom); // BIDET

            //autre façon de l'ecrire    
            Console.WriteLine("\n ");
            Salarie salarie3 = new Salarie
            {
                Nom = "Moison",
                Prenom = "Felixine"
            };
            Console.WriteLine(salarie3.Nom + " " + salarie3.Prenom);
            string presentation = salarie3.SePresenter();
            Console.WriteLine(presentation);
            Console.WriteLine(leSalarie.SePresenter());

            Console.WriteLine("\n autre cas ");
            TousLesSalaries.Add(leSalarie);
            TousLesSalaries.Add(salarie3);
            TousLesSalaries.Add(new Salarie("Chereaux", "Anna"));
            TousLesSalaries.Add(null);

            leSalarie.Prenom = "Appoline";
            TousLesSalaries[1].Prenom = "Clemence";
            ModifierListe(2, "Claire",TousLesSalaries);

            salarie3.SePresenter();
            // gestion du directeur 
            Console.WriteLine("-----------------------------------------  ");
            Console.WriteLine("\n CAS directeur  ");
            Directeur dir = new Directeur("BOURGET","Bernard");
            dir.SePresenter();
            //Personne personne = new Personne("Dubois", "Raphael");
            
            Console.WriteLine(dir.SePresenter()); // isabelle
           

            Console.WriteLine("\n CAS des compteurs  ");
            // liste des salariés
            foreach (Salarie s in TousLesSalaries)
            {
                Console.WriteLine( s?.SePresenter());
                // le compteur non static est  sur l'instance et non la class 
                Console.WriteLine("compteur dans le salarie " + s?.Compteur);
                // le compteur static est lui sur la class et non sur l'instance 
                Console.WriteLine("on a : " + Salarie.CompteurSalarie + "  salarie(s) " );
                Console.WriteLine("c'est le salarie n° " + s?.CompteurDuSalarie);

            }
            // pour une copie de liste 
            Console.WriteLine("\n autre cas ");
            List<Salarie> Liste2 = new List<Salarie>(TousLesSalaries);

            // pour une copie de reference
            List<Salarie> Liste3 = Liste2;
            Liste2[0].Prenom = "Isabelle";

            Console.WriteLine(Liste2[0].Prenom);// isabelle
            Console.WriteLine(Liste3[0].Prenom);// isabelle
            Console.WriteLine(TousLesSalaries[0].Prenom); // isabelle

            Console.WriteLine(Salarie.DonneeCompteur());

            Console.WriteLine("\n autre cas ");

            Console.WriteLine("\n-----------------------------------------  ");
            Console.WriteLine(" La reunion  ");
            // copie la liste des salaries + directeur  dans la liste des menbres de la reunion 
            // on est sur du polymorphisme
            // le directeur est une personne donc il peut être vu comme une personne 
            // idem pour le salarie
            MembreDeLaReunion = new List<Personne>(TousLesSalaries);
            MembreDeLaReunion.Add(dir);
            //MembreDeLaReunion.Add(personne);

            // exemple de ce qu'on faire ou non sur la class personne qui est abstraite
            Salarie toto = new Salarie();
            //Salarie S2 = new Personne(" ", " ");
            Personne pers1 = new Salarie();
            Personne pers2 = new Directeur(" ", " ");

            foreach (Personne p in MembreDeLaReunion)
            {
                Console.WriteLine(p); // on affiche le nom de la class de la personne 
                if (p != null)
                {
                    Console.WriteLine(p.SeRendreAuTravail());
                    Console.WriteLine(p.SePresenter());
                    p.Payer();
                    if (p.GetType() == typeof(Salarie))
                    {
                            // polymorphisme
                        Salarie s = (Salarie)p;
                        Console.WriteLine("transcripage  " + s.Compteur);
                        Console.WriteLine("Autre façon d'ecrire " + ((Salarie)p).Compteur);
                    }
                }
            }
            Console.WriteLine("-----------------------------------------  ");

            // le polymorphisme fonctionne aussi avec les interfaces
            List<IPayables> payables = new List<IPayables>(MembreDeLaReunion);
            foreach (IPayables payable in payables)
            {
                if (payable != null)
                {
                    payable.Payer();
                }
            }
            IDisposable exempleDisposable = new Salarie();
            exempleDisposable.Dispose();

            // using appelle .dispose de l'objet utilisé
            // impose que l'objet implementIDisposable
            // l'objet existe que pour la durée du using
            using (Salarie exempleAvecUsing = new Salarie())
            {
                exempleAvecUsing.Payer();
                Console.WriteLine("on fait les chose ");
            } // appel automatique de dispose 
            // on va mettre dedans l'ecriture ou l'acces aux fichiers base de données

            // serialisation
            // la on recupère que le type 
            // XmlSerializer serializer = new XmlSerializer(MembreDeLaReunion.GetType());
            // autre façon d'ecrire 
            // objet permettant la serialisation
            XmlSerializer serializer = new XmlSerializer(typeof(List<Personne>));
            // flux en ecriture pour ecrire dans un fichier

            // on est dans des connexion exterieur mais rajouter un try Cash pour géré des exceptions
            using (StreamWriter writer =
                new StreamWriter(@"c:\serialisation\salaries.xml "))
            {
                serializer.Serialize(writer, MembreDeLaReunion);
            }

        }

        private static void ModifierListe(int index, string prenom, List<Salarie> Liste)
        {
            Liste[index].Prenom = prenom;
        }
    }
}
