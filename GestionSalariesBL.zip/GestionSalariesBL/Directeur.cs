﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionSalariesBL
{
    public class Directeur : Personne
    {

        //on peut pas l'ecrire car le directeur ne possede pas une personne 
        //public Personne personne { get; set; } du coup on mets : Personne dans la class Directeur
        public Directeur() { }
        public string ParachuteDore { get; set; }
        public Directeur(string nom, string prenom) :base(nom,prenom) {   }

        /// <summary>
        /// override precise qu'on redefinit une methode parente
        /// </summary>
        /// <returns></returns>
        public override string SePresenter()
        {
            return $"M. {Prenom } {Nom} Directeur : Bonjour à tous . "; 
        }

        public override string SeRendreAuTravail()
        {
            return "Le directeur se rend au travail avec son chauffeur ";
        }
    }
}
