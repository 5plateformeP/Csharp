﻿using GestionDesSalariesInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace GestionSalariesBL
{/// <summary>
 /// là on a forcmeent en second une interface 
 /// IDisposable est une interface syteme mise a disposition
 /// si on hérite d'1 objet et qu'on implement 1 ou plusieurs interfaces
 /// l'objet est en premier et les interfaces apres 
 /// </summary>
 ///
    [XmlInclude(typeof(Salarie))]
    [XmlInclude(typeof(Directeur))]
    public abstract class Personne :object, IPayables , IDisposable
    {
      
        #region attributs /champs
        protected string nom;
        private string prenom;
        #endregion

        #region proprités
        public string Nom
        {
            get // pour donner 
            {
                // on renvoi le nom s'il existe , sinon INCONNU
                //return nom ?? "[INCONNU]";
                // si non nom on renvoi en mascule et le ? c'est pour eviter de planter si vide lors du passe en majuscule
                return nom?.ToUpper() ?? "[INCONNU]";
            }
            set // pour valoriser 
            {
                // if(( !string.IsNullOrWhiteSpace(value)) && ( value.Length > 2))
                // if (value != null && value.Trim().Length > 2)
                // ? si null sur la donnée on sort
                if (value?.Trim().Length > 2)
                {
                    nom = value;
                }
            }
        }
        // c'est la version sans controle , on peut pavoir plusqieurs ligne dans le get ou le set 
        public Personne()
        {
        }
        public string Prenom { get => prenom; set => prenom = value; }

        #endregion
        #region constructeurs
        public Personne(String nom, String prenom)
        {
            this.nom = nom;
            this.prenom = prenom;
        }
        #endregion
        #region methode
        // virtual permet de edefinir la methode 
        public virtual string SePresenter()
        // si on prend nom on prend la valeur saisie
        // si on prend Nom on prend la valeur controlée
        {
            return $" Bonjour je m'appelle {prenom } {nom } .";
            //return $" Bonjour je m'appelle {prenom } {nom } . {DonnerCompteur}";
        }
        public abstract string SeRendreAuTravail();

        public void Payer()
        {
            if (this.GetType() == typeof(Directeur))
            {
                Console.WriteLine($" On paye le directeur {prenom } {nom } .");
            }
            else if (this.GetType() == typeof(Salarie))
            {
                Console.WriteLine($" On paye un salarié {prenom } {nom } .");
            }
            else
            {
                throw new Exception("CAS NON TRAITE");
            }

        }

        public bool IsJourDeLaPaye(DateTime date)
        {
            return date.Day == 1;
        }

        public void Dispose()
        {
            // pour coder la liberation des ressources de fichiers , base de connées
            Console.WriteLine("C'est terminé, on a bient tout nettoyé");
        }


        #endregion
    }

    /*
     * F5 : lancer l'application en mode debug
CTRL+F5 : lancer l'application sans le mode debug
(ajoute dans une application console une ligne de pause à la fin du programme)

F12 (ou CTRL+CLIC) : aller à la définition
Shift+F12 : voir toutes les références (d'une variable, d'une méthode) 

CTRL+ESPACE : autocomplétion (entrée pour valider)

CTRL+; Vous propose une ou des solutions à un problème (convention de nommage, simplification, etc...)

CTRL+: mettre ou retirer les commentaires
CTRL+K+C : mettre en commentaire
CTRL+K+U : retirer en commentaire

CTRL+SHIFT+B : Compiler

Debug (F5):
    F5 : pour aller au prochain point d'arrêt (ou jusqu'à la fin du programme)
    F10 : instruction suivante
    F11 : entrer dans la méthode ou, si ce n'est pas possible, instruction suivante
    
CTRL+SHIFT+U : passer majuscules
CTRL+U : passer minuscules

ALT+glisser souris : sélection multigne
     */
}
