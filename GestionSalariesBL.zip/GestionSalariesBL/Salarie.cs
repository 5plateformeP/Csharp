﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionSalariesBL
{
    /// <summary>
    /// il est codé ainsi :  
    /// Accéssibilité : ont est presque toujours en public 
    ///  class
    ///  Nom de la class
    ///  public sealed Salarie : Personne pour empecher l'heritage sur Salarie
    ///  icic comptable ne pourra pas e=herite de salarie
    /// </summary>
    public class Salarie : Personne
    {
        #region attributs /champs
        // accessibilité , type , un nom ( commence par minuscule)
        // dans les bonnes pratiques jamais public
        // public accessible à tous 
        // private seul la class peut y acceder
        #endregion

        #region proprités
        // idem que attribut , mais publique et on peut ajouter un peu de contrôle avec des get set 
        public Personne SuperieurHierarchique { get; set; }
        public int Compteur { get; set; }
        public int CompteurDuSalarie { get; set; }
        public static int CompteurSalarie { get; set; }
        #endregion

        #region constructeurs
        public Salarie() : base("inconnu","inconnu")
        {
            Console.WriteLine("Un salarie a été créé ");
            // le compteur est une proprité du salarie
            Compteur++;
            // le compteur dess salarie est static
            // il n'appartient pas à l instance 
            // mais a la class
            CompteurSalarie++;
            CompteurDuSalarie = CompteurSalarie;  
        }

        public Salarie(string nom): this()
        {
            Nom = nom;
        }
            // objectif initialiser notre instance  
            // on peut avoir plusieurs constructeur 
            //accessibilité , type nom de nom 
            // si on crée un contructeur le constructeur par defaut disparait 
            //public Salarie( string nom = "[inconnu]", string FirstName = "[inconnu]")

            // on retire les valeur par defaut car on a créé un contructeur par defaut avant 
            //this() on appelle le constructeur de cette instance sans paramètre 
            //this(nom) appel constructeur possedant un paramètre de type string
            public Salarie(string nom , string FirstName ) : this(nom)
        {

            // de base le salarié doit avoir un nom 
            // on forcve par defaut "[inconnu]"  
            //Nom = nom;
            //THIS assignation à l'attibut de l'instance de salarie
            this.nom = nom ; 
            // base permet l'acces au preprité de la base mère 
            base.Prenom = FirstName;
        }
        #endregion

        #region méthodes
        // accessibilité , type , un nom 
        // une methode non static 
        //          des methodes et variables  non static 
        //          des methodes et variables  non static 
       
        /// <summary>
        /// une methode static ne peux appeler que
        ///     une variable ou un methode static
        /// </summary>
        /// <returns></returns>
        public static string DonneeCompteur()
        {
            return $"Nous  sommes { CompteurSalarie};";
        }

        public override string SeRendreAuTravail()
        {
            return $"{Prenom } arrive en vélo .  ";
        }
        #endregion

    }
}
