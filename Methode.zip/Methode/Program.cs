﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methode
{
    class Program
    {
        static void Main(string[] args)
        {
            // methode qui dit bonjour à quelqu'un 
            DisBonjour("Harrison ","Ford");
            long resultatAdd = Addition2Valeurs(2691, 1258);
            Console.WriteLine("resultat addition 1 " + resultatAdd);
            Console.WriteLine("resultat addition 1 " + Addition2Valeurs(1, 1258));
            Console.WriteLine("resultat addition 2 " + Addition2ValeursA(1, 1258));
            Console.WriteLine("resultat addition 2 " + Addition2ValeursA(1, 1258, 256));
            int[] entiers = { 3, 12, 57, -5, 25, 36, 256, 1258964, -569874 };
            Console.WriteLine("resultat addition liste " + calculer(entiers));
            Console.WriteLine("resultat addition liste " + calculer(3, 12, 57, -5, 25, 36, 256, 1258964, -569874));

            ParametreEnSortie();
            PassageParReference();
        }

        private static void PassageParReference()
        {
            // passage par reference, il doit etre initialisé 
            int resultat = 0;

            // on met ref pour la valeur de sortie , pour dire que c'est de la sortie, 
            // on les passe par reference pour des type primitif  ou des objets immuables ( string ) 
            // pour les objets le passage de param se fait toujours par ref , donc on le precise pas 
            Additionner(3, 4, ref resultat);
            Console.WriteLine("Mon resultat " + resultat);

        }

        private static void Additionner(int a, int b, ref int resultat)
        {
            resultat = a + b; 
        }

        private static void ParametreEnSortie()
        {
            // on va faire une methode qui dit , est un nombre pair ou pas et 
            int valeur;
            if (AffecteSiPair(out valeur))
            {
                Console.WriteLine($"{valeur} est pair");
            }
            else
            {   
                Console.WriteLine($" la valeur est impaire ou la valeur n est pas initialisé : { valeur} .");
            }

            // declaration inline
            if (AffecteSiPair2(out int valeur2))
            {
                Console.WriteLine($"{valeur2} est pair");
            }
            else
            {
                Console.WriteLine($" la valeur est impaire ou la valeur n est pas initialisé : { valeur2} .");
            }
        }

        private static bool AffecteSiPair2(out int valeur2)
        {
            Console.WriteLine(" Merci de saisie un entier :");
            String saisie = Console.ReadLine();
            bool result = false;
            int resultat;

            if (int.TryParse(saisie, out resultat))
            {
                valeur2 = resultat;
                result = valeur2 % 2 == 0;

                if (!result) valeur2 = 0;
                return result;
            }
            else
            {
                valeur2 = 0;
                return false;
            }
        }

        private static bool AffecteSiPair(out int valeur)
        {
            Console.WriteLine(" Merci de saisie un entier :");
            String saisie = Console.ReadLine();
            bool result = false; 
            try
            {
                valeur = int.Parse(saisie);
                result = valeur %2 ==0 ;
                if (!result) valeur = 0;
            }
                        catch
            {
                Console.WriteLine("Format incorrecte. ");
                valeur = 0;
            }
            return result;
        }

        // private que pour cette methoe 
        // public tout le monde peu l'appeler 
        private static void DisBonjour(string prenom, string nom)
        {
            // throw new NotImplementedException(); a mettre en commentaire , mis quand on le cree CTRL ; pour le faire planter
            Console.WriteLine("Bonjour " + prenom + " " + nom);
            Console.WriteLine($"Bonjour {prenom} {nom}" );
            Console.WriteLine($"Bonjour \"{prenom} {nom}\"" );
        }

        private static long Addition2Valeurs(int valeur1, int valeur2)
        {
            return valeur1 + valeur2;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="valeur1"></param>
        /// <param name="valeur2"></param>
        /// <param name="Valeur3">0 si non renseigné</param>
        /// <returns></returns>
        // un fonction avec un valeur optionnel 
        private static long Addition2ValeursA(int valeur1, int valeur2, int Valeur3 = 0) 
        {
            return valeur1 + valeur2 + Valeur3;
        }
        private static long calculer(params int[] entiers)
        {
            return entiers.Sum();
        }
    }
}
