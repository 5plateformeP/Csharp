﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tableaux
{
    class Program
    {
        static void Main(string[] args)
        {
            // declaration des tableau a une dimension: 
            // un tableau est declaré avec une structure figée
            int[] tab1Dim = new int[3];
            string[] tabl1Dim2 = { "Sylvain", "Raphael","Sophie"};
            // l'acces au tableau 
            Console.WriteLine(tabl1Dim2[1]);
            // on modifie la valeur 
            tabl1Dim2[1] = "Raphaël avec un trema";
            Console.WriteLine(tabl1Dim2[1]);

            // nombre d'argument du tableau
            Console.WriteLine("longueur du tableau" + tabl1Dim2[1].Length);


            // valeur minimum du tableau
            int[] tabl1Dim3 = { 3, 12, 57, -5, 25, 36, 256, 1258964, -569874 };
            Console.WriteLine("valeur minimum du tableau " + tabl1Dim3.Min());
            Console.WriteLine("valeur maximum du tableau " + tabl1Dim3.Max());
            Console.WriteLine("La somme  du tableau " + tabl1Dim3.Sum());
            Console.WriteLine("La moyenne du tableau " + tabl1Dim3.Average());

            // nombre d'argument du tableau
            //Console.WriteLine("longueur du tableau" + tabl1Dim2[1].Length);
            //TABLEAU A 2 DIMENSION
            int[,] monTableauA2Dimensions = new int[5, 2];
            monTableauA2Dimensions[0, 0] = 12;

            int[,] monTableauA2DimensionsInitialise =
            {
                {2,32 },
                {-7,12 },
                { 247,765}
            };
            Console.WriteLine(monTableauA2DimensionsInitialise[2, 1]);
            //Console.WriteLine(monTableauA2DimensionsInitialise[2, 2]); // exception erreur car la colonne 2 existe pas car on commence a 0

            // tableau de tableau
            int[][] tableauDeTableau = new int[5][];
            tableauDeTableau[0] = tabl1Dim3;
            tableauDeTableau[1] = new int[2] ;

            Console.WriteLine(tableauDeTableau[0][1]);
        }
    }
}
