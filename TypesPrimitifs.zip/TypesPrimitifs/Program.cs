﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypesPrimitifs
{
    /// <summary>
    /// règle de nommage  : camel case 
    ///                     commençant par une majuscule  MaClassExemple
    /// </summary>
    class Program
    {
 
        /// <summary>
        ///  pour la documentation de mon code 
        ///  règle de nommage  : camel case 
        ///                      commençant par une majuscule  MaClassExemple
        /// </summary>
        /// <param name="args">mes paramètres</param>
        static void Main(string[] args)
        {
            #region commantaire 
            // commentaire sur une ligne 
            /* */ //commentaires sur plusieurs lignes , ou commenter une partie de ligne
            /* 
             *
             */

            // déclaration d'une variable : type suivi du nom de la variable
            //règle de nommage  : camel case 
            //                    commençant par une minuscule  maVaraible
            int monEntier;
            monEntier = 3;
            Console.WriteLine(monEntier);
            double monDouble = 2.5;
                        #endregion

            #region TYPE PRIMITFS
            // entiers signés
            // sbytes(8 - 1 octet) , short(16) , int(32) ,long( 64 bytes) 
            // si on fait 
            byte monByte = 3;
            Console.WriteLine(monByte);
            // il y a une autoconversion en INT 
            //
            // entiers non signés
            // bytes(8 - 1 octet) , ushort(16) , uint(32) ,ulong( 64 bytes) 
            int hexa = 0xFF;

            // les décimaux 
            // float(32) ,  double(64) , decimal (64)
            // le decimal est plus gourmant mais plus precis 
            float monFloat = 32.0F;
            // erreur 
            double monDouble2 = 32.0;
            decimal monDEc = 32m;
 
            Console.WriteLine(monDouble2);
            //ok

            monDouble = monFloat; // cat implicite
            monFloat =   (float)monDouble; // cast explicite

            // booléens
            bool monBooleen = true; //false
            Console.WriteLine(monBooleen);

            // caractères
            char monChar = 'a'; // simple ' car c'est juste un caractère sinon " pour la chaine
            Console.WriteLine(monChar);
            monChar = '\n';   // saut de ligne  ,
            // \t : tabl 
            // \\ : pour anti-slash, 
            // /' : quote
            // /" pour echarper un guillement plutot dans une chaine de caractère 

            // chaine caractère ( pas type primtifs ) 
            string maChaine = "ma chaine "; // entre guillements 
            Console.WriteLine(maChaine);

            string path = @"https://mensuel.framapad.org/p/9fg9-dawan2020_csharp"; // @ pour mettre un chemin et ne pas avoir à double les / du texte
            Console.WriteLine(path);


            #endregion
            #region WRAPPERS et conversion
            // wrapeur , se sont des objet qui remplacent les primitifs
            Int32 unInt = 12;
            // ça sert plus 

            //pour convertir une chaine en numrique 
            unInt = int.Parse("42");
            unInt = Convert.ToInt32("57");
            #endregion

            #region operateur
            // opérateur mathématique 
            // + - * / % 
            // opérateur conditionnels 
            // == != < > ! ( négation)
            // &&  : ET     ,    || : OU

            monBooleen = !true;
            monBooleen = !(monEntier % 2 == 0);  // vrai si monEntier est impair 
            monBooleen = !(monEntier % 2 == 0) && !monBooleen;  // si la partie de gauche est faux , on fera pas celle de droite , ça permet de se proteger des valeurs inconnues  
            monBooleen = !(monEntier % 2 == 0) || !monBooleen;  // si la partie de gauche est vrai , on fera pas celle de droite , ça permet de se proteger des valeurs inconnues  


            // opérateur d'affectation
            // ++  --   +=   /=   *=    %= 
            int i = 0;//0 
            i = i + 1; //1
            i += 5; //6
            i++; //7  de base c'est plus 1 , post increment
            ++i; // 8 pre_incrment


            int j = 0;
            Console.WriteLine(j);
            Console.WriteLine(j++);  //0 car affiche avant de faire le calcul
            Console.WriteLine(++j); // 2 car affiche apres le calcul

            // operateur de concatenation
            double resultat = 1;
            resultat = 1 / 3;  // conversion implicite entier / entier alors il donne un entier
            Console.WriteLine("resultat : " + resultat); // 0 

            resultat = 1 / 3.0;  // 1 des 2 est en double alors resultat en double 
            Console.WriteLine("resultat : " + resultat);//0.3333333333
            resultat = (double)1 / 3;
            Console.WriteLine("resultat : " + resultat);//0.3333333333
            resultat = 1d  / 3;
            Console.WriteLine("resultat : " + resultat);//0.3333333333
            resultat = 1f / 3;
            Console.WriteLine("resultat : " + resultat);//0.33334326741 moins precis et du coup plus que 33 a la fin 

            // un type primitif ne peux pas etre null
            /*bool b;
            Console.WriteLine(b); // pas de droit de la faire */
            // sauf si on les declare ainsi : 
            int? monIntNullable = null;


            #endregion
        }
    }
}
