﻿namespace WinForms
{
    partial class MaForm
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnPremier = new System.Windows.Forms.Button();
            this.ChkCoche = new System.Windows.Forms.CheckBox();
            this.LblInfo = new System.Windows.Forms.Label();
            this.BtnDecocher = new System.Windows.Forms.Button();
            this.BtnAjouter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnPremier
            // 
            this.BtnPremier.Enabled = false;
            this.BtnPremier.Location = new System.Drawing.Point(109, 32);
            this.BtnPremier.Name = "BtnPremier";
            this.BtnPremier.Size = new System.Drawing.Size(75, 23);
            this.BtnPremier.TabIndex = 0;
            this.BtnPremier.Text = "&Cocher";
            this.BtnPremier.UseVisualStyleBackColor = true;
            this.BtnPremier.Click += new System.EventHandler(this.CocherDeCocher_Click);
            // 
            // ChkCoche
            // 
            this.ChkCoche.AutoSize = true;
            this.ChkCoche.Checked = true;
            this.ChkCoche.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChkCoche.Location = new System.Drawing.Point(202, 63);
            this.ChkCoche.Name = "ChkCoche";
            this.ChkCoche.Size = new System.Drawing.Size(82, 17);
            this.ChkCoche.TabIndex = 2;
            this.ChkCoche.Text = "C\'est coché";
            this.ChkCoche.UseVisualStyleBackColor = true;
            this.ChkCoche.CheckedChanged += new System.EventHandler(this.ChkCoche_CheckedChanged);
            // 
            // LblInfo
            // 
            this.LblInfo.AutoSize = true;
            this.LblInfo.Location = new System.Drawing.Point(358, 67);
            this.LblInfo.Name = "LblInfo";
            this.LblInfo.Size = new System.Drawing.Size(43, 13);
            this.LblInfo.TabIndex = 3;
            this.LblInfo.Text = "coucou";
            // 
            // BtnDecocher
            // 
            this.BtnDecocher.Location = new System.Drawing.Point(109, 84);
            this.BtnDecocher.Name = "BtnDecocher";
            this.BtnDecocher.Size = new System.Drawing.Size(75, 23);
            this.BtnDecocher.TabIndex = 4;
            this.BtnDecocher.Text = "&Decocher";
            this.BtnDecocher.UseVisualStyleBackColor = true;
            this.BtnDecocher.Click += new System.EventHandler(this.CocherDeCocher_Click);
            // 
            // BtnAjouter
            // 
            this.BtnAjouter.Location = new System.Drawing.Point(109, 134);
            this.BtnAjouter.Name = "BtnAjouter";
            this.BtnAjouter.Size = new System.Drawing.Size(122, 42);
            this.BtnAjouter.TabIndex = 5;
            this.BtnAjouter.Text = "&Ajouter un bouton";
            this.BtnAjouter.UseVisualStyleBackColor = true;
            this.BtnAjouter.Click += new System.EventHandler(this.BtnAjouter_Click);
            // 
            // MaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 225);
            this.Controls.Add(this.BtnAjouter);
            this.Controls.Add(this.BtnDecocher);
            this.Controls.Add(this.LblInfo);
            this.Controls.Add(this.ChkCoche);
            this.Controls.Add(this.BtnPremier);
            this.Icon = global::WinForms.Properties.Resources.jade;
            this.Name = "MaForm";
            this.Text = "Ma premiere WinForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnPremier;
        private System.Windows.Forms.CheckBox ChkCoche;
        private System.Windows.Forms.Label LblInfo;
        private System.Windows.Forms.Button BtnDecocher;
        private System.Windows.Forms.Button BtnAjouter;
    }
}

