﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinForms.Properties;

namespace WinForms
{
    public partial class MaForm : Form
    {
        private int CompteurDeClic;
        private int CompteurDeBouton;
        public MaForm()
        {
            InitializeComponent();
        }
        private void InitForm()
        {
            // code spécifique à cette fenetre pour être sur de pas la perdre 
            Icon = WinForms.Properties.Resources.jade;
            LblInfo.Text = string.Empty;
        }

        private void BtnAjouter_Click(object sender, EventArgs e)
        {
            // on cree le bouton 
            ++CompteurDeBouton;
            Button nouveauBouton = new Button
            {
                Text = "Nouveau " + CompteurDeBouton,
                Name = "BtnNouveau " + CompteurDeBouton,
                Size = new Size(82, 25),
                Tag = CompteurDeBouton,
                Location = new Point(500, 1 + (CompteurDeBouton * 30))
            };

            nouveauBouton.Click += new EventHandler(Nouveau_click);
            // mais il faut l'ajouter à la form , instance 
            this.Controls.Add(nouveauBouton);
        }

        private void Nouveau_click(object sender, EventArgs e)
        {
            if (sender.GetType() == typeof(Button))
            {
                // on recupere le bouton a l'origine 
                Button MonBouton = ( Button) sender ;
                DialogResult resulat =
                    MessageBox.Show(MonBouton.Tag.ToString(), "Confirmation", MessageBoxButtons.YesNoCancel);
            
                if (resulat == DialogResult.Yes)
                {
                    MessageBox.Show("Vous avez dit oui");
                }
            }
        }
        private void CocherDeCocher_Click(object sender, EventArgs e)
        {
            // click du bouton Cocher
            // on  teste si on est bien sur un bouton , car si case async coché alors plantafe 
            if (sender.GetType() == typeof(Button))
            {
                // pour connaitre quel boutons est a l'origine de l'event
                Button bouton = (Button)sender;
                bouton.Text += "."; // on a joute un . dans le text du boutons à chaque clique
            }
            CompterClics();
            ChangerEtat();
        }
        private void ChkCoche_CheckedChanged(object sender, EventArgs e)
        {
            ChangerEtat(false);
        }
        private void ChangerEtat(bool changeChecked = true)
        {

            if (changeChecked)  ChkCoche.Checked = !ChkCoche.Checked;
    
            BtnPremier.Enabled = !ChkCoche.Checked;
            BtnDecocher.Enabled = ChkCoche.Checked;
            ChkCoche.Text= ChkCoche.Checked ? " C'est décocheé" : "C'est coché ";

            //Button b = new button();
        }
        private void CompterClics()
        {
            CompteurDeClic++;
           
            string chaine = CompteurDeClic < 2 ?
                    Properties.Resources.T_COMPTEUR_CLIC  :
                    Properties.Resources.T_COMPTEUR_CLICS;

            LblInfo.Text = string.Format(chaine, CompteurDeClic);
            //LblInfo.Text = $"{++CompteurDeClic} clics ";
        }

    }
}
