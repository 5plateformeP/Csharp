﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace condition
{
    class Program
    {
        static void Main(string[] args)
        {

            //si();
            switchcase();
            
        }


        private static void switchcase()
        {
            // on a créé une enumeration
            // switch / case 

            Console.WriteLine("Veuillez saisir votre nom  :");
            string saisie = Console.ReadLine();
            bool nonRenseigne = false;

            Civilite civilite = Civilite.INCONNU; 
            if (string.IsNullOrWhiteSpace(saisie))
            {
                nonRenseigne = true;
                Console.WriteLine("Le nom est obligatoire ! : ");
            }
               else if (saisie.StartsWith("admin"))
            {
                nonRenseigne = false;
                civilite = Civilite.AUTRE_CIVILITE;
                Console.WriteLine("Bonjour : " + saisie);
            }
            else
            {
                nonRenseigne = false;
                Console.WriteLine("$Bonjour :  { saisie }  ! ");
                civilite = Civilite.MADAME;

            }

            // on est que sur des constantes
            switch (civilite)
            {
                // la mademoiselle et madame font le meme traitement 
                case Civilite.MADEMOISELLE:
                case Civilite.MADAME:
                    Console.WriteLine("Vous etes une femme ");
                    Console.WriteLine("Bonjour madame  ");
                    break;
                case Civilite.MONSIEUR:
                    Console.WriteLine("Vous etes une homme ");
                    Console.WriteLine("Bonjour Monsieur  ");
                    goto case Civilite.AUTRE_CIVILITE;
                case Civilite.AUTRE_CIVILITE:
                    break;
                default:
                     Console.WriteLine("bonjour ");
                    break;
            }

            // condition resultat si vrai : resultat si faux 
            // c'est un si sur 1 ligne 

            string resultat = (civilite == Civilite.MONSIEUR) ? " Vous etes un homme " : " Ou femme  ";
                       Console.WriteLine(resultat);
            resultat = (civilite == Civilite.MADAME) ? " Vous etes un femme " : null;
                    Console.WriteLine(resultat);

            // affectation par defaut
            string resultatFinal = resultat ?? "Valeur par défaut";
            Console.WriteLine("REsultat Final " + resultatFinal);

            // dans la prochaine version de CSHARP  les 2 lignes seront alors identique
            resultatFinal = resultatFinal ?? "Valeur par défaut";
            //  resultatFinal ??=  "Valeur par défaut";

            // les execptions
            // les exceptiosn coutent chere , il vaut mieux les gérer en amon par des IF
            Console.WriteLine(" Saisissez un entier : " );
            string saisieEntier = Console.ReadLine();
            int entier = 0;
            try
            {
                // ne mettre que le min de cade dans le try
                entier = int.Parse(saisieEntier);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Pas le bon Format ! ");
                throw ex;
            }
            catch (Exception ex)
            {
                // on fait quelques chosee
                Console.WriteLine(ex.Message);
                // on arrête
                // exemple : on trace dans un fichier 

                // là on crach nous meme l'appli car c'est une erreur outils throw  dans ce cas on pourra pas faire le return derrière
                throw new Exception("On avait demandé un entier ");

                //return;
            }

            finally
            {
                Console.WriteLine("On passe Toujours là");
            }


            Console.WriteLine(Environment.NewLine);
            Console.WriteLine("on fait +1 sur la saisie");
            Console.WriteLine(  ++ entier);

        }

        private static void si()
        {
            // if /else if /else
            // c'est un si alors , sinon dans la sinon on a un si , et le dernier sinon est si les 2 autre conditions sont pas remplis
            // accolades facultatives si le if continet qu'une instruction, mais elles sont recommandées
            Console.WriteLine("Veuillez saisir votre nom  :");
            string saisie = Console.ReadLine();
            bool nonRenseigne = false ;
            if (string.IsNullOrWhiteSpace(saisie))
            {
                // attention à la portée des variables 
                // une variable declarée dans un corps n'existera qu'à l'intérieur de ce corps 
                nonRenseigne = true;
                Console.WriteLine("Le nom est obligatoire ! : ");
                saisie = Console.ReadLine();
            }
            // est ce que la chaine commence par admin
            else if (saisie.StartsWith("admin"))
            {
                nonRenseigne = false;
                Console.WriteLine("Bonjour : " + saisie);
            }
            else
            {
                nonRenseigne = false;
                Console.WriteLine("$Bonjour :  { saisie }  ! ");
            }
        }
    }
}
