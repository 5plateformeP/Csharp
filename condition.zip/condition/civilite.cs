﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace condition
{
    // on cré ue enumeration
    public enum Civilite
    {
        INCONNU,
        MADAME,
        MONSIEUR,
        MADEMOISELLE,
        AUTRE_CIVILITE
    }
}
